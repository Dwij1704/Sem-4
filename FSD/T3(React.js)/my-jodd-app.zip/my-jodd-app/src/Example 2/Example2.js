import React from "react";
const Example2 = () => {  
    return <h1>Module Import Example</h1>;
}
export default Example2